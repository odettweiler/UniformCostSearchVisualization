import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class UniformCostSearch extends PApplet {

Graph graph;
ArrayList<Node> nl = new ArrayList<Node>();
PFont f;
boolean finished = false;
boolean running = false;

boolean connecting = false;
Node connectingFrom = null;

Node start;
Node goal;

int frameIntervalIdx = 4;
int[] frameIntervalOptions = {2, 4, 5, 10, 20, 30, 60};

Path currentPath;
Node current;
ArrayList<Path> fringe = new ArrayList<Path>();

public void setup() {  
  // custom graph
  graph = new Graph(0);
  
  //println(graph.allLens());
  
  frameRate(60);
  
  f = createFont("Arial",16,true);
}

public void draw() {
  background(255);
  graph.drawSelf();
  
  drawCompletedText();
  
  ucs();
  
  drawConnecting();
}

public void mousePressed() {
  if (!running) {
    if (mouseButton == LEFT) {
      if (!connecting) {
        Node n = new Node(new ArrayList<Connection>(), graph.getNextName(), new PVector(mouseX, mouseY));
        graph.addNode(n);
      }
    } else if (mouseButton == RIGHT) {
      if (connecting) {
        Node n = graph.getNodeAtCoords(mouseX, mouseY);
        if (n != null) {
          connectingFrom.addConnectionTo(n);
          connecting = false;
        } else {
          connectingFrom = null;
          connecting = false;
        }
      } else {
        Node n = graph.getNodeAtCoords(mouseX, mouseY);
        if (n != null) {
          connecting = true;
          connectingFrom = n;
        }
      }
    }
  }
}

public void keyPressed() {
  if (key == 'r') {
    // reset ucs program
    resetUCS();
    running = false;
    finished = false;
  } else if (key == 'q') {
    // init with example graph
    running = false;
    finished = false;
    clearGraph();
    resetUCS();
    
    InitNodeList();
    graph = new Graph(nl);
  }else if (key == 's') {
    // set starting node
    Node n = graph.getNodeAtCoords(mouseX, mouseY);
    if (n != null) {
      start = n;
      println(start.name);
    }
  } else if (key == 'c') {
    // clear graph
    clearGraph();
    resetUCS();
    running = false;
    finished = false;
  } else if (key == 'e') {
    // set ending node
    Node n = graph.getNodeAtCoords(mouseX, mouseY);
    if (n != null) {
      goal = n;
      println(goal.name);
    }
  } else if (key == 't') {
    // start ucs program
    startUCS();
  } else if (key == 'p') {
    // stop ucs program
    running = false;
    finished = false;
  } else if (keyCode == UP) {
    // increase speed if possible
    if (frameIntervalIdx != 0) {
      frameIntervalIdx--;
    }
  } else if (keyCode == DOWN) {
    // decrease speed if possible
    if (frameIntervalIdx < frameIntervalOptions.length-1) {
      frameIntervalIdx++;
    }
  }
}

public void drawConnecting() {
  if (connecting) {
    line(connectingFrom.pos.x, connectingFrom.pos.y, mouseX, mouseY);
  }
}

// uniform cost search
/* determine which path to take by
finding all possible next steps and
taking the one with the least cost */

public void resetUCS() {
  fringe = new ArrayList<Path>();
  
  currentPath = null;
  current = null;
  
  start = null;
  goal = null;
}

public void startUCS() {
  running = true;
  finished = false;
  
  if (start == null) start = graph.nodes.get(0);
  if (goal == null) goal = graph.nodes.get(graph.nodes.size()-1);
  
  current = start; // init current node
  
  ArrayList<Node> nList = new ArrayList<Node>();
  nList.add(start);
  currentPath = new Path(current, nList); // init path
  
  addNeighborPathsToFringe(fringe, current, currentPath);
}

public void clearGraph() {
  graph = new Graph(0);
  running = false;
}

public void ucs() {
  if (running) {
    currentPath.drawSelf();
    // draw here ^^
    
    if (!finished) {
      if(fringe.size() != 0) {
        if (frameCount % frameIntervalOptions[frameIntervalIdx] == 0) {
          // execute one step of this every second
          
          // advance through the fringe
          currentPath = getShortestPathIn(fringe);
          current = getShortestPathIn(fringe).to;
          fringe.remove(getShortestPathIn(fringe));
          
          // check if goal has been reached
          if (current == goal) {
            currentPath.drawSelf();
            println(currentPath.cost);
            finished = true;
            // yay!!
          }
          
          // add neighbors to fringe
          addNeighborPathsToFringe(fringe, current, currentPath);
        }
      }
    }
  }
}

public Path getShortestPathIn(ArrayList<Path> fringe) {
  int minLen = Integer.MAX_VALUE;
  Path shortestPath = null;
  for (Path p : fringe) {
    if (p.cost < minLen) {
      minLen = p.cost;
      shortestPath = p;
    }
  }
  
  return shortestPath;
}

public void addNeighborPathsToFringe(ArrayList<Path> fringe, Node current, Path path) {
  for (Node n : current.getNeighbors()) {
    ArrayList<Node> nl = (ArrayList<Node>) path.nodeList.clone();
    
    nl.add(n);
    Path p = new Path(n, nl);
    addToFringe(fringe, p);
  }
}

public void addToFringe(ArrayList<Path> fringe, Path path) {
  if (!fringe.contains(path)) {
    fringe.add(path);
  }
}

public void InitNodeList() {
  ArrayList<Connection> aConn = new ArrayList<Connection>();
  Node a = new Node(aConn, 'a', new PVector(400, 100));
  nl.add(a);
  
  ArrayList<Connection> bConn = new ArrayList<Connection>();
  Node b = new Node(bConn, 'b', new PVector(266, 400));
  nl.add(b);
  
  ArrayList<Connection> cConn = new ArrayList<Connection>();
  Node c = new Node(cConn, 'c', new PVector(666, 400));
  nl.add(c);
  
  ArrayList<Connection> dConn = new ArrayList<Connection>();
  Node d = new Node(dConn, 'd', new PVector(100, 700));
  nl.add(d);
  
  ArrayList<Connection> eConn = new ArrayList<Connection>();
  Node e = new Node(eConn, 'e', new PVector(400, 700));
  nl.add(e);
  
  ArrayList<Connection> fConn = new ArrayList<Connection>();
  Node f = new Node(fConn, 'f', new PVector(700, 700));
  nl.add(f);
  
  a.addConnectionTo(b);
  a.addConnectionTo(c);
  
  b.addConnectionTo(d);
  b.addConnectionTo(e);
  
  c.addConnectionTo(f);
  
  e.addConnectionTo(f);
}

public void drawCompletedText() {
  if (finished) {
    textFont(f,32);
    stroke(0);
    fill(0);
    text("Finished!", 325, 25);
  }
}
class Connection {
  Node from;
  Node to;
  int len;
  
  public Connection(Node f, Node t, int l) {
    this.from = f;
    this.to = t;
    this.len = l;
  }
  
  public void drawSelf() {
    stroke(0);
    fill(0);
    strokeWeight(1);
    line(from.pos.x, from.pos.y, to.pos.x, to.pos.y);
    PVector midpoint = new PVector((from.pos.x+to.pos.x)/2, (from.pos.y+to.pos.y)/2);
    // text
    textFont(f,16);
    stroke(0);
    fill(0);
    text(this.len, midpoint.x, midpoint.y-40);
  }
  
  public void drawSelfSpecial() {
    stroke(73, 219, 255);
    fill(0);
    strokeWeight(4);
    line(from.pos.x, from.pos.y, to.pos.x, to.pos.y);
    PVector midpoint = new PVector((from.pos.x+to.pos.x)/2, (from.pos.y+to.pos.y)/2);
    // label length near midpoint
  }
}
class Graph {
  char[] names = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
  int nameIndex = -1;
  ArrayList<Node> nodes = new ArrayList<Node>();
  
  public Graph(int numNodes) {
    for (int i = 0; i < numNodes; i++) {
      //addRandomNode();
      nodes.add(new Node(getNextName(), new PVector(random(width), random(height))));
    }
    
    for (int i = 0; i < numNodes-1; i++) {
      connectToRandomNodes(nodes.get(i), numNodes);
      //nodes.get(i).addConnectionTo(nodes.get(i+1)); // change to connect more randomly
      //if (i == numNodes-2) {
      //  nodes.get(numNodes-1).addConnectionTo(nodes.get(0));
      //}
    }
  }
  
  public Graph(ArrayList<Node> nl) {
    nodes = nl;
  }
  
  public ArrayList<Connection> getAllConnections() {
    ArrayList<Connection> conn = new ArrayList<Connection>();
    for (Node n : this.nodes) {
      for (Connection c : n.getConnections()) {
        conn.add(c);
      }
    }
    
    return conn;
  }
  
  public int allLens() {
    int sum = 0;
    for (int i = 0; i < nodes.size(); i++) {
      Node n = nodes.get(i);
      for (Connection c : n.connections) {
        sum += c.len;
      }
    }
    return sum;
  }
  
  public char getNextName() {
    if (nameIndex >= 25) {
      nameIndex = 0;
    } else {
      nameIndex++;
    }
    
    return names[nameIndex];
  }
  
  public void drawSelf() {
    ArrayList<Connection> conn = getAllConnections();
    for (Connection c : conn) {
      c.drawSelf();
    }
    for (Node n : this.nodes) {
      n.drawSelf();
    }
  }
  
  public void addNode(Node n) {
    this.nodes.add(n);
  }
  
  public Node getNodeAtCoords(int x, int y) {
    for (int i = 0; i < nodes.size(); i++) {
      Node n = nodes.get(i);
      if (PVector.dist(n.pos, new PVector(x, y)) <= 50) {
        return n;
      }
    }
    
    return null;
  }
  
  private void connectToRandomNodes(Node n, int totalNodes) {
    int numConnections = (int) random(totalNodes/4, totalNodes/2);
    for (int i = 0; i < numConnections; i++) {
      int idx = (int) random(totalNodes);
      n.addConnectionTo(this.nodes.get(idx));
    }
  }
  
  private void addRandomNodes() {
    
    // add a random node if it's far enough away from other nodes
  }
}
class Node {
  ArrayList<Connection> connections = new ArrayList<Connection>();
  char name;
  PVector pos;
  
  public Node(ArrayList<Connection> conn, char n, PVector p) {
    this.connections = conn;
    this.name = n;
    this.pos = p;
  }
  
  public Node(char n, PVector p) {
    this.name = n;
    this.pos = p;
  }
  
  public ArrayList<Node> getNeighbors() {
    ArrayList<Node> nodes = new ArrayList<Node>();
    for (Connection c : connections) {
      nodes.add(c.to);
    }
    return nodes;
  }
  
  public ArrayList<Connection> getConnections() {
    return this.connections;
  }
  
  public void addConnectionTo(Node to) {
    this.connections.add(new Connection(this, to, floor(getDistTo(to.pos))));
  }
  
  public Connection getConnectionTo(Node to) {
    Connection conn = null;
    for (Connection c : connections) {
      if (c.to == to) conn = c;
    }
    return conn;
  }
  
  public float getDistTo(PVector otherPos) {
    return sqrt(pow(otherPos.x - this.pos.x, 2) + pow(otherPos.y - this.pos.y, 2)) / 100;
  }
  
  public void drawSelf() {
    stroke(0);
    strokeWeight(1);
    fill(255);
    ellipse(pos.x, pos.y, 50, 50);
    
    textFont(f,16);
    stroke(0);
    fill(0);
    text(this.name, pos.x, pos.y);
  }
  
  public void drawSelfSpecial() {
    stroke(73, 219, 255);
    strokeWeight(1);
    fill(73, 219, 255);
    ellipse(pos.x, pos.y, 50, 50);
    
    textFont(f,16);
    stroke(0);
    fill(0);
    text(this.name, pos.x, pos.y);
  }
  
  public void drawSelfSpecial2() {
    stroke(53, 255, 134);
    strokeWeight(1);
    fill(53, 255, 134);
    ellipse(pos.x, pos.y, 50, 50);
    
    textFont(f,16);
    stroke(0);
    fill(0);
    text(this.name, pos.x, pos.y);
  }
  
  @Override
  public String toString() {
    return Character.toString(this.name);
  }
}
class Path {
  Node to;
  ArrayList<Node> nodeList = new ArrayList<Node>();
  int cost;
  
  public Path(Node t, ArrayList<Node> nl) {
    this.to = t;
    this.nodeList = nl;
    
    this.cost = 0;
    for (int i = 0; i < this.nodeList.size()-1; i++) {
      Node n = this.nodeList.get(i);
      Connection c = n.getConnectionTo(this.nodeList.get(i+1));
      if (c != null) {
        this.cost += c.len;
      }
    }
  }
  
  public ArrayList<Connection> getAllConnections() {
    ArrayList<Connection> conn = new ArrayList<Connection>();
    for (int i = 0; i < nodeList.size()-1; i++) {
      conn.add(nodeList.get(i).getConnectionTo(nodeList.get(i+1)));
      if (i == nodeList.size()-2) {
        conn.add(nodeList.get(nodeList.size()-1).getConnectionTo(nodeList.get(0)));
      }
    }
    if (conn.isEmpty()) {
      return null;
    } else {
      return conn;
    }
  }
  
  public void drawSelf() {
    int co = 0;
    for (int i = 0; i < nodeList.size(); i++) {
      if (i < nodeList.size()-1) {
        Connection c = nodeList.get(i).getConnectionTo(nodeList.get(i+1));
        co += c.len;
        c.drawSelfSpecial();
      }
      nodeList.get(i).drawSelfSpecial2();
    }
    to.drawSelfSpecial();
  }
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "UniformCostSearch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
